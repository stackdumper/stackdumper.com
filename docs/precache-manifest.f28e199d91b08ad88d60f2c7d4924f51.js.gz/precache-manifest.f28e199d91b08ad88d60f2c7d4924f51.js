self.__precacheManifest = [
  {
    "revision": "9f26679a39516ca1e13e",
    "url": "bundle.js"
  },
  {
    "revision": "9f26679a39516ca1e13e",
    "url": "styles.css"
  },
  {
    "revision": "3548d057af9877641453",
    "url": "1.bundle.js"
  },
  {
    "revision": "b88f9d72cf7db8b2fd3a",
    "url": "2.bundle.js"
  },
  {
    "revision": "f777d4e6f30548a49ada6ce2c69d2c92",
    "url": "index.html"
  },
  {
    "url": "icon_512x512.360cc477dd38a936dc773d359fb0774b.png"
  },
  {
    "url": "icon_384x384.59d2fb30263857310e436079ed8a8091.png"
  },
  {
    "url": "icon_256x256.dff285cc4c8157c41154e847ece7691d.png"
  },
  {
    "url": "icon_192x192.b114363eaaa6f372e09778c8d2cf92f5.png"
  },
  {
    "url": "icon_128x128.442bbbb88714e994e69092079412699b.png"
  },
  {
    "url": "icon_96x96.dde439653705e85314c447bb930fccb3.png"
  }
];